from django.contrib import admin
from home.models import signup,signups,subtopic,subject
# Register your models here.

admin.site.register(signup)
admin.site.register(signups)
admin.site.register(subject)
admin.site.register(subtopic)