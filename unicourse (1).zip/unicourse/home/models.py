from operator import mod
from django.db import models
from django.contrib.auth.models import User


# Create your models here.

class  signup(models.Model):
    
    clgname=models.TextField( max_length=150)
    
    
    phone=models.TextField(max_length=12)

    semester= models.TextField( max_length=2)
    
    dob=models.DateField()

    gender=models.TextField(max_length=20)

    pic=models.ImageField(null=True, blank=True)
    
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True,)

    todaydate=models.TextField(max_length=15)

    branch= models.TextField( max_length=150)

    
class  signups(models.Model):
    
    clgname=models.TextField( max_length=150)
    
    
    phone=models.TextField(max_length=12)

    semester= models.TextField( max_length=2)
    
    dob=models.DateField()

    gender=models.TextField(max_length=20)

    pic=models.ImageField(null=True, blank=True)
    
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True,)

    todaydate=models.TextField(max_length=15)

    branch= models.TextField( max_length=150)
    
    # def __str__(self) :
    #     return self.user
    



class subject((models.Model)):
    subject_name= models.TextField( max_length=400)
    module1 = models.TextField( max_length=400)
    module2 = models.TextField( max_length=400)
    module3 = models.TextField( max_length=400)
    module4 = models.TextField( max_length=400)
    module5 = models.TextField( max_length=400)
    user = models.TextField( max_length=400)
    active=models.BooleanField(default=False)
    def __str__(self) :
        return self.subject_name

class subtopic((models.Model)):
    sub_topic=models.TextField( max_length=400)
    module_name = models.TextField(max_length=400,)
    video=models.TextField( max_length=500,null=True, blank=True )
    pdf=models.TextField( max_length=500,null=True, blank=True)
    
    def __str__(self) :
        return self.sub_topic