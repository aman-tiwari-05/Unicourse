from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout 
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from home.models import signups,subtopic,subject
import unicourse.settings
from datetime import date


profiles=[
    {'id':1,'name':'Aman '},
    {'id':2,'name':'Aarav '},
    {'id':3,'name':'Amit '}
]

def index(request):
    return render(request,'index.html')

def content(request,subj):
            
            subjn=subject.objects.filter(subject_name=subj,user=request.user)
            for Subject_name in subjn:
                module1=Subject_name.module1
                module2=Subject_name.module2
                module3=Subject_name.module3
                module4=Subject_name.module4
                module5=Subject_name.module5

            
            # context={"sub_name":Subject_name}
            
            
                if(Subject_name.active):
                    subtopics1=subtopic.objects.filter(module_name=module1)
                    subtopics2=subtopic.objects.filter(module_name=module2)
                    subtopics3=subtopic.objects.filter(module_name=module3)
                    subtopics4=subtopic.objects.filter(module_name=module4)
                    subtopics5=subtopic.objects.filter(module_name=module5) 
                
                
                    context={'sub_name':Subject_name.subject_name,'mod1':module1,'mod2':module2,'mod3':module3,'mod4':module4,'mod5':module5, "subtopics1":subtopics1, "subtopics2":subtopics2, "subtopics3":subtopics3, "subtopics4":subtopics4, "subtopics5":subtopics5}
                    return render(request,'content.html',context)
            
                else:
                    context={'sub_name':Subject_name.subject_name,'mod1':module1,'mod2':module2,'mod3':module3,'mod4':module4,'mod5':module5}
                    return render(request,'content.html',context)

def signin(request):
    
     
    if request.method=='POST':
        
        username= request.POST.get('username')
        password=request.POST.get('password')
        # try:
        #     user= User.objects.get(username=username)
        # except User.DoesNotExist:
            
        #     messages.error(request, 'User does not exist')
        user= authenticate(request,username=username,password=password)

        if user is not None:
            login(request,user)
            print("Yes") 
            return redirect('profile')
        else:
            print("NO") 
            messages.error(request, 'Wrong Username or Password')
            return redirect('signin')
    else:
        return render(request,'login.html')
    
@login_required(login_url="login")
def profile(request):
    
    Subject_name=subject.objects.filter(user=request.user)
    

    context={'subjects':Subject_name,'user':request.user } 
   
    return render(request,'profile.html',context)

def signup(request):
    if request.method == "POST":
        username = request.POST['username']
        name = request.POST['name']
        
        email = request.POST['email']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']
        bran=request.POST['branch']
        sem=request.POST['sem']
        dob=request.POST['dob']
        pic=request.POST['pic']
        todaydate=date.today()
        
        
        colgname=request.POST['clgname']
        
        mobno=request.POST['phone']
        gender=request.POST['gender']
        if User.objects.filter(username=username):
            messages.error(request, "username already exist")
            return redirect('signup')
        if User.objects.filter(email=email):
            messages.error(request, "Email already exist")
            return redirect('signup')
        if pass1 != pass2:
            messages.error(request, "Passwords didn't matched!!")
            return redirect('signup')
        myuser = User.objects.create_user(username, email, pass1)
        fname,lname=name.split()
        myuser.first_name = fname
        myuser.last_name = lname
        
        print(bran, type(bran))
        details2=signups(clgname=colgname,semester=sem,phone=mobno,branch=bran,pic=pic,gender=gender,todaydate=todaydate,user=myuser,dob=dob)
        details2.save()
        

        


        
        myuser.save()
        user= authenticate(username=username,password=pass1)
        login(request,myuser)
        return redirect('profile')
    return render(request,'signup.html')

    
def signout(request):
    logout(request)
    return redirect("login")

def add(request):
    if request.method == "POST":
        subname=request.POST['subname']
        module1=request.POST['module1']
        subtopics1=request.POST['subtopic1']
        module2=request.POST['module2']
        subtopics2=request.POST['subtopic2']
        module3=request.POST['module3']
        subtopics3=request.POST['subtopic3']
        module4=request.POST['module4']
        subtopics4=request.POST['subtopic4']
        module5=request.POST['module5']
        subtopics5=request.POST['subtopic5']


        

        new_subject=subject(subject_name=subname,module1=module1,module2=module2,module3=module3,module4=module4,module5=module5,user=request.user)

        new_subject.save()
        arr1=list(subtopics1.split(','))
        arr2=list(subtopics2.split(','))
        arr3=list(subtopics3.split(','))
        arr4=list(subtopics4.split(','))
        arr5=list(subtopics5.split(','))
        
        
        
        for i  in range(len(arr1)):
            
            sub_topic=subtopic(sub_topic=arr1[i],module_name=module1)
            sub_topic.save()
        for topic in arr2:

            sub_topic=subtopic(sub_topic=topic,module_name=module2)
            sub_topic.save()
        for topic in arr3:

            sub_topic=subtopic(sub_topic=topic,module_name=module3)
            sub_topic.save()
        for topic in arr4:

            sub_topic=subtopic(sub_topic=topic,module_name=module4)
            sub_topic.save()
        for topic in arr5:

            sub_topic=subtopic(sub_topic=topic,module_name=module5)
            sub_topic.save()
        return redirect('profile')
    


    return render(request,'add.html')
        
