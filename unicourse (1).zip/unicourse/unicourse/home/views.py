from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout 
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from home.models import signup,signups
import unicourse.settings
from datetime import date


profiles=[
    {'id':1,'name':'Aman '},
    {'id':2,'name':'Aarav '},
    {'id':3,'name':'Amit '}
]

def index(request):
    return render(request,'index.html')

def content(request):
    return render(request,'content.html')

def signin(request):
    
     
    if request.method=='POST':
        
        username= request.POST.get('username')
        password=request.POST.get('password')
        # try:
        #     user= User.objects.get(username=username)
        # except User.DoesNotExist:
            
        #     messages.error(request, 'User does not exist')
        user= authenticate(request,username=username,password=password)

        if user is not None:
            login(request,user)
            print("Yes") 
            return redirect('profile')
        else:
            print("NO") 
            messages.error(request, 'Wrong Username or Password')
            return redirect('signin')
    else:
        return render(request,'login.html')
    
@login_required(login_url="login")
def profile(request):
    
   
    return render(request,'profile.html')

def signup(request):
    if request.method == "POST":
        username = request.POST['username']
        name = request.POST['name']
        
        email = request.POST['email']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']
        bran=request.POST['branch']
        sem=request.POST['sem']
        dob=request.POST['dob']
        pic=request.POST['pic']
        todaydate=date.today()
        
        
        colgname=request.POST['clgname']
        
        mobno=request.POST['phone']
        gender=request.POST['gender']
        if User.objects.filter(username=username):
            messages.error(request, "username already exist")
            return redirect('signup')
        if User.objects.filter(email=email):
            messages.error(request, "Email already exist")
            return redirect('signup')
        if pass1 != pass2:
            messages.error(request, "Passwords didn't matched!!")
            return redirect('signup')
        myuser = User.objects.create_user(username, email, pass1)
        fname,lname=name.split()
        myuser.first_name = fname
        myuser.last_name = lname
        
        print(bran, type(bran))
        details2=signups(clgname=colgname,semester=sem,phone=mobno,branch=bran,pic=pic,gender=gender,todaydate=todaydate,user=myuser,dob=dob)
        details2.save()
        

        


        
        myuser.save()
        user= authenticate(username=username,password=pass1)
        login(request,myuser)
        return redirect('profile')
    return render(request,'signup.html')

    
def signout(request):
    logout(request)
    return redirect("login")
