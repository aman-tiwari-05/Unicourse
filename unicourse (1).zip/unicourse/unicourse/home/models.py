from operator import mod
from django.db import models
from django.contrib.auth.models import User


# Create your models here.

class  signup(models.Model):
    
    clgname=models.TextField( max_length=150)
    
    
    phone=models.TextField(max_length=12)

    semester= models.TextField( max_length=2)
    
    dob=models.DateField()

    gender=models.TextField(max_length=20)

    pic=models.ImageField(null=True, blank=True)
    
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True,)

    todaydate=models.TextField(max_length=15)

    branch= models.TextField( max_length=150)
    
class  signups(models.Model):
    
    clgname=models.TextField( max_length=150)
    
    
    phone=models.TextField(max_length=12)

    semester= models.TextField( max_length=2)
    
    dob=models.DateField()

    gender=models.TextField(max_length=20)

    pic=models.ImageField(null=True, blank=True)
    
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True,)

    todaydate=models.TextField(max_length=15)

    branch= models.TextField( max_length=150)
    

