from django.contrib import admin
from home.models import signup,signups
# Register your models here.

admin.site.register(signup)
admin.site.register(signups)
